const STORAGE_KEY = "dnd-party-tracker-v1";
const MAX_PLAYERS = 5;
const DEFAULT_STATS = { STR: 10, DEX: 10, CON: 10, INT: 10, WIS: 10, CHA: 10 };

const playersEl = document.getElementById("players");
const emptyState = document.getElementById("emptyState");
const limitMessage = document.getElementById("limitMessage");
const playerTemplate = document.getElementById("playerTemplate");
const abilityTemplate = document.getElementById("abilityTemplate");

let players = load();

function load() {
  try {
    const data = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return Array.isArray(data) ? data : [];
  } catch {
    return [];
  }
}

function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(players));
}

function newPlayer() {
  return {
    id: crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36),
    name: `Player ${players.length + 1}`,
    stats: { ...DEFAULT_STATS },
    abilities: []
  };
}

function newAbility() {
  return {
    id: crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random(),
    name: "",
    damage: "",
    requirement: "",
    description: ""
  };
}

function render() {
  playersEl.innerHTML = "";
  emptyState.classList.toggle("hidden", players.length > 0);

  players.forEach((player, index) => {
    const card = playerTemplate.content.cloneNode(true);
    const article = card.querySelector(".player-card");

    article.dataset.playerId = player.id;
    card.querySelector(".player-number").textContent = index + 1;

    const name = card.querySelector(".player-name");
    name.value = player.name;
    name.addEventListener("input", e => {
      player.name = e.target.value;
      save();
    });

    card.querySelectorAll(".stat-input").forEach(input => {
      const stat = input.dataset.stat;
      input.value = player.stats[stat] ?? 0;
      input.addEventListener("input", e => {
        const value = Math.max(0, Math.min(30, Number(e.target.value) || 0));
        player.stats[stat] = value;
        e.target.value = value;
        save();
      });
    });

    card.querySelector(".delete-player").addEventListener("click", () => {
      if (confirm(`"${player.name}" verwijderen?`)) {
        players = players.filter(p => p.id !== player.id);
        save();
        render();
      }
    });

    const abilities = card.querySelector(".abilities");
    const emptyAbilities = card.querySelector(".no-abilities");

    player.abilities.forEach(ability => {
      abilities.appendChild(renderAbility(player, ability));
    });
    emptyAbilities.classList.toggle("hidden", player.abilities.length > 0);

    card.querySelector(".add-ability").addEventListener("click", () => {
      player.abilities.push(newAbility());
      save();
      render();
      const allCards = playersEl.querySelectorAll(".player-card");
      const currentCard = allCards[index];
      currentCard?.querySelector(".ability-name")?.focus();
    });

    playersEl.appendChild(card);
  });

  const atLimit = players.length >= MAX_PLAYERS;
  document.getElementById("addPlayerBtn").disabled = atLimit;
  document.getElementById("emptyAddBtn").disabled = atLimit;

  limitMessage.classList.toggle("hidden", !atLimit);
  if (atLimit) limitMessage.textContent = "Je hebt het maximum van 5 players bereikt.";
}

function renderAbility(player, ability) {
  const fragment = abilityTemplate.content.cloneNode(true);
  const el = fragment.querySelector(".ability");

  const name = fragment.querySelector(".ability-name");
  const damage = fragment.querySelector(".ability-damage");
  const requirement = fragment.querySelector(".ability-requirement");
  const description = fragment.querySelector(".ability-description");

  name.value = ability.name;
  damage.value = ability.damage;
  requirement.value = ability.requirement;
  description.value = ability.description;

  name.addEventListener("input", e => { ability.name = e.target.value; save(); });
  damage.addEventListener("input", e => { ability.damage = e.target.value; save(); });
  requirement.addEventListener("input", e => { ability.requirement = e.target.value; save(); });
  description.addEventListener("input", e => { ability.description = e.target.value; save(); });

  fragment.querySelector(".delete-ability").addEventListener("click", () => {
    player.abilities = player.abilities.filter(a => a.id !== ability.id);
    save();
    render();
  });

  return el;
}

function addPlayer() {
  if (players.length >= MAX_PLAYERS) return;
  players.push(newPlayer());
  save();
  render();

  const cards = playersEl.querySelectorAll(".player-card");
  cards[cards.length - 1]?.querySelector(".player-name")?.focus();
}

document.getElementById("addPlayerBtn").addEventListener("click", addPlayer);
document.getElementById("emptyAddBtn").addEventListener("click", addPlayer);

document.getElementById("resetBtn").addEventListener("click", () => {
  if (confirm("Alle players, stats en abilities verwijderen?")) {
    players = [];
    save();
    render();
  }
});

render();
