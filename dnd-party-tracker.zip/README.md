# D&D Party Tracker

Een simpele D&D character/party tracker die volledig in de browser werkt.

## Features

- Maximaal 5 players
- STR, DEX, CON, INT, WIS en CHA
- Stats direct aanpassen
- Per player onbeperkt abilities/moves
- Per ability:
  - Naam
  - Damage
  - Requirement
  - Beschrijving
- Automatisch opslaan met `localStorage`
- Responsive voor telefoon en desktop
- Geen database of backend nodig
- Geschikt voor GitHub Pages

## Op GitHub zetten

1. Maak een nieuwe GitHub repository.
2. Upload `index.html`, `style.css` en `script.js`.
3. Ga naar **Settings → Pages**.
4. Kies bij Source: **Deploy from a branch**.
5. Kies de `main` branch en `/ (root)`.
6. Sla op.
7. GitHub geeft je daarna een Pages-link.

## Data

De data wordt lokaal opgeslagen in de browser van de gebruiker. Een andere browser of ander apparaat heeft dus een eigen lijst.
